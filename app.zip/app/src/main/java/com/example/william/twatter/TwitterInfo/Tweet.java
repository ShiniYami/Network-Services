package com.example.william.twatter.TwitterInfo;

/**
 * Created by William on 5/9/2017.
 */

public class Tweet {
    public String getAuthorName() {
        return authorName;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    private String authorName = "Unknown";
    private String text = "Empty";
    public Tweet(String author,String text) {
        this.authorName = author;
        this.text = text;
    }


    public void setAuthorName(String name) {
        authorName = name;
    }
}
