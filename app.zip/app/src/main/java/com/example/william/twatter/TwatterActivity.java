package com.example.william.twatter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.william.twatter.TwitterInfo.User;

public class TwatterActivity extends AppCompatActivity implements UserListFragment.ItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twatter);
    }

    @Override
    public void userSelected(User user) {
            UserListFragment listFrag1 = (UserListFragment) getFragmentManager().findFragmentById(R.id.listfrag);
        TweetListFragment listFrag2 = new TweetListFragment();
        getFragmentManager().beginTransaction().remove(listFrag1).commit();
        getFragmentManager().beginTransaction().add(R.id.container1,listFrag2).commit();
    }
}
