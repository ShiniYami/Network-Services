package com.example.william.twatter;

import android.app.Fragment;

/**
 * Created by William on 5/9/2017.
 */

public class DetailActivity extends Fragment {
}
