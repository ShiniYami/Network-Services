package com.example.william.twatter.TwitterInfo;

import java.util.ArrayList;

/**
 * Created by William on 5/9/2017.
 */

public class Entity {
    private ArrayList<String> hashtags = new ArrayList<>();
    private ArrayList<String> mentions = new ArrayList<>();
    private String imageUrl;

}
