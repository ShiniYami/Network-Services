package com.example.william.twatter;

import com.example.william.twatter.TwitterInfo.Tweet;

import java.util.ArrayList;

/**
 * Created by William on 5/17/2017.
 */

class TweetData {
    public ArrayList<Tweet> getTweets() {
        return tweets;
    }

    public void setTweets(ArrayList<Tweet> tweets) {
        this.tweets = tweets;
    }

    ArrayList<Tweet> tweets = new ArrayList<>();
    private static final TweetData ourInstance = new TweetData();

    static TweetData getInstance() {
        return ourInstance;
    }

    private TweetData() {
    }

}
