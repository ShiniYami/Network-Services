package com.example.william.twatter.TwitterInfo;

import java.util.ArrayList;

/**
 * Created by William on 5/9/2017.
 */

public class User {
    private String name;
    ArrayList<Tweet> myTweets;
    public User(String name, ArrayList<Tweet> tweets){
        this.name = name;
        myTweets = tweets;
        for (Tweet tweet:myTweets
             ) {
            tweet.setAuthorName(name);
        }
    }
    public ArrayList<Tweet> getTweets(){
        return myTweets;
    }

}
