package com.example.william.twatter;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.william.twatter.R;
import com.example.william.twatter.TwitterInfo.Tweet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by William on 5/9/2017.
 */

public class TweetListFragment extends Fragment {
    TwatModel model = TwatModel.getInstance();
    JSONObject object = model.getListObject();
    ArrayList<Tweet> tweets = new ArrayList<>();
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_tweet_list,container);//false means it won't be attatched to the rootView by itssellf, because android will already do that for me
        ListView lv = (ListView) rootView.findViewById(R.id.tweetList);
        final ArrayList<Tweet> tweets = new ArrayList<>();
        try{
            JSONArray testItems = object.getJSONArray("statuses");
            for (int x = 0;x<testItems.length();x++){
                JSONObject object = testItems.getJSONObject(x);
                String name = object.getString("id_str");
                String text = object.getString("text");
                tweets.add(new Tweet(name,text));
            }
            tweets.add(new Tweet("Hello","Wouter"));
            TweetData tweetDataModel = TweetData.getInstance();
            tweetDataModel.setTweets(tweets);
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        TweetListAdapter adapt = new TweetListAdapter(getActivity(),R.layout.tweet_list_item,tweets);
        lv.setAdapter(adapt);
        return rootView;
    }
}
