package com.example.william.twatter;

import com.example.william.twatter.TwitterInfo.Tweet;
import com.example.william.twatter.TwitterInfo.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by William on 5/9/2017.
 */

class TwatModel {

    JSONObject object = new JSONObject();
    private ArrayList<User> users = new ArrayList<>();
    private static final TwatModel ourInstance = new TwatModel();

    static TwatModel getInstance() {
        return ourInstance;
    }

    private TwatModel() {
//        users.add(new User("william",new ArrayList<Tweet>()));
        try {
            Scanner reader = new Scanner(new File("C:\\Users\\William\\Downloads\\BrownWilliam429581\\Twatter\\app\\src\\main\\java\\com\\example\\william\\twatter\\test.json"));
            try {
                object = new JSONObject(reader.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public ArrayList<User> getUsers(){
        return users;
    }
    public JSONObject getListObject(){return object;}
}
